CREATE VIEW dbo.V_HRTOCB
AS
SELECT     TOP (100) PERCENT dbo.A01.A0190 AS employee_id, dbo.A01.A0101 AS employee_name, 
                      CASE WHEN content LIKE 'CQ%' THEN 'CQ' ELSE 'CZ' END AS 'plant_location', dbo.A01.A020Q AS cost_center, dbo.A01.A01zZ0B AS work_center, 
                      dbo.A01.A0209 AS management_level, dbo.A01.A01zcmc AS 'job_position', dbo.A01.GW_name AS 'job_position_detail', 
                      dbo.A01.A01zZ0C AS team_leader_day_shift_id, dbo.A01.A01zZ0D AS team_leader_day_shift_name, dbo.A01.A01zZ0E AS team_leader_night_shift_id, 
                      dbo.A01.A01zZ0F AS team_leader_night_shift_name, dbo.K15.K1500 AS 'shift'
FROM         dbo.A01 INNER JOIN
                      dbo.DEPTCODE ON dbo.A01.Dept_id = dbo.DEPTCODE.DEPT_ID INNER JOIN
                      dbo.K15 ON dbo.A01.A0188 = dbo.K15.A0188
WHERE     (dbo.A01.A0191 = '在职人员') AND (dbo.K15.D9999 = dbo.dat1(GETDATE()))
ORDER BY dbo.A01.Dept_id, employee_id
GO
